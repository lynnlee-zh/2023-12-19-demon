#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding:utf-8
# python 3.0 

import subprocess  
import socket     
import sys
from datetime import datetime
import platform
import shutil  
import os    
import urllib
from urllib.request import Request, urlopen  
from urllib.parse import urlencode   
import argparse  
import json

#用到的几个变量               
github_user_name = "" #用户名
github_token = "" #用户token     
repo_name = "" #仓库名   
zip_name =  "2023-12-19-github_bait.zip"  #诱饵压缩文件名称
  
github_api_domain = "api.github.com"      
github_api_url = "https://api.github.com/user/repos"   #url地址  
github_post_head_json = "application/vnd.github+json"    #   

             
#验证网络是否连通   
def is_domain_reachable(domain):  
    try:   
        socket.gethostbyname(domain)  
        return True,""  
    except socket.gaierror:  
        return False,""
        
#验证token是否正确     
def login():    
    url = "https://api.github.com/user"   
    headers = {
        "Authorization": "token {}".format(github_token), 
        'Accept': '{}'.format(github_post_head_json), 
        'Content-Type': 'application/json'
    } 
    success = False    
    error = ""        
    # 发送请求并获取响应 
    code,resp  = getReq(url,headers)     
    if code == 200:
        success = True  
    return success,error
     
def getReq(url,headers):   
    try:  
        req = Request(url,headers=headers) 
        resp = urlopen(req)
        data = resp.read()
        code = resp.getcode()
    except urllib.error.HTTPError as e:
        code = 0
        data = "" 
    except urllib.error.URLError as e:  
        code = 0
        data = ""  
    return code,data 
 
def postReq(url,headers,data):
    try:   
        req = Request(url,headers=headers,data = data)
        resp = urlopen(req)
        data = resp.read()
        code = resp.getcode()
    except urllib.error.HTTPError as e:
        code = 0
        data = "" 
    except urllib.error.URLError as e:  
        code = 0
        data = ""   
    return code,data    

     
# 创建远程仓库    
def createRepo():    
    #print("create repo")  
    url = 'https://api.github.com/user/repos'   
    headers = {
        "Authorization": "token {}".format(github_token), 
        'Accept': '{}'.format(github_post_head_json),    
        'Content-Type': 'application/json'
    }      
    data = {"name": "{}".format(repo_name),"auto_init":True} 
    success = False  
    error = ""   
    data_json = json.dumps(data)    
    code,data = postReq(url,headers,data=data_json.encode('utf-8')) 
  
    if len(data) == 0:  
        success = False
        return success,error   
      
    jsond = json.loads(data.decode())    
    return_name =  jsond.get("name","") 
    if return_name == repo_name:
        success = True 
    return success,error   
        
# 判断远端仓库是否已存在 
def isRepoExist():     
    url = 'https://api.github.com/repos/{}/{}'.format(github_user_name,repo_name) 
    isExists = False
    headers = {  
        'Accept':'{}'.format(github_post_head_json),   
        'Authorization':'Bearer {}'.format(github_token),  
        'X-GitHub-Api-Version':'2022-11-28',   
    }   
    # 发送请求并获取响应    
    code,resp  = getReq(url,headers)     
    if code == 200:
        isExists = True    
    return isExists
    
# 克隆远程仓库    
def cloneRepo():
      
    #清空用户           
    runCommand("cd ./{} &&  git config --global --unset user.name ")
    runCommand("cd ./{} &&  git config --global --unset user.email ")  
    
    #print("clone repo")  
    cmdStr = "git clone https://{}@github.com/{}/{}.git".format(github_token,github_user_name,repo_name)         
    resp,code = runCommand(cmdStr)      
    #检测是否成功           
    if code != 0:
        return False
    else:
        return True 
     
# git 提交以及推送 
def pushRepo():
    url = ""    
    #放入文件   
    if platform.system() == "Windows":   
        cmdStr = "copy ./{} ./{}/{}".format(zip_name,repo_name,zip_name)    
    else:
        cmdStr = "cp ./{} ./{}/{}".format(zip_name,repo_name,zip_name)              
    err,code = runCommand(cmdStr)     
    if code != 0:      
        return "add bait file fail",url 
 
    # 判断一下本地仓库     
    if os.path.exists("./{}".format(repo_name) ) == False:  
        #git 设置token         
        err,code = runCommand("cd ./{} && git remote set-url origin https://{}@github.com/{}/{}.git".format(repo_name,github_token,github_user_name,repo_name))  
        if code != 0:         
            return "repo set token fail",url 
           
    #写时间文件 保证每次都能推送成功 
    file = open("./{}/time.txt".format(repo_name),"w") 
    file.write("commit time {}".format(datetime.now()))  
    file.close()           
     
    #必须配置邮箱以及用户名,假的也行，否则无法提交      
    runCommand("cd ./{} &&  git config --global user.email 'you@example.com' ".format(repo_name))
    runCommand("cd ./{} &&  git config --global user.name '{}' ".format(repo_name,github_user_name))    
         
    #git add .             
    err,code = runCommand("cd ./{} &&  git add .".format(repo_name)) 
    if code != 0:     
        return "local git repo add file fail",url   
    #git commit -a -m "xxx"  
    now = datetime.now()        
    err,code = runCommand('cd ./{} && git commit -a -m "{}"'.format(repo_name,now))  
    if code != 0:          
        return "local git repo commit fail",url      
    #git push                
    err,code = runCommand("cd ./{} && git push".format(repo_name))
    if code != 0:                
        return "git push fail",url    
    return "success","https://github.com/{}/{}.git".format(github_user_name,repo_name)
      
# 移除本地仓库目录
def deleteRepo(): 
    err = ""
    try:  
       shutil.rmtree(repo_name)
    except OSError as e:     
       err = "发布成功，清理仓库文件夹报错: {}".format(e)
    return err
   
# 命令执行函数    
def runCommand(command):          
    #result = subprocess.run(command, shell=True, capture_output=True, text=True)
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    return result.stderr,result.returncode
       
def checkParams(): 
    isValid = True
    paramsList = [github_user_name,github_token,repo_name,zip_name,github_api_domain,github_api_url,github_post_head_json] 
    for item in paramsList:
        if len(item) == 0:
            isValid = False
            break 
    return isValid,""
               
if __name__ == "__main__":    
    #解析参数-单独调用方法    
    # eg:  python .\publish_github_tpl.py -m checkParams  
    parser = argparse.ArgumentParser(description="调用指定方法") 
    parser.add_argument("-m",type=str,help="方法名称参数",default="") 
    args = parser.parse_args()  
    method = args.m 
    if len(method) > 0: 
        if method == "checkParams":
            ret,err = checkParams()
            print(ret)   
            sys.exit()       
        if method == "is_domain_reachable": 
            ret,err = is_domain_reachable(github_api_domain)
            print(ret) 
            sys.exit()        
        if method == "login":
            ret,err = login() 
            print(ret)
            sys.exit()      
        if method == "isRepoExist": 
            ret = isRepoExist()  
            print(ret) 
            sys.exit()    
        if method == "createRepo":
            ret,err = createRepo()
            print(ret) 
            sys.exit()      
        if method == "cloneRepo":   
            ret = cloneRepo()
            print(ret)   
            sys.exit()     
        if method == "pushRepo":    
            err,url = pushRepo() 
            if "success" in err:
                print(err+url)  
            else:  
                print(err)    
            sys.exit()     
        if method == "deleteRepo":    
            err = deleteRepo()
            print(err)  
            sys.exit()    
            
    #按照顺序执行  
    #参数检查       
    isValid = checkParams()
    if isValid == False:           
        print("参数为空或不可用，请检查")  
        sys.exit()  
    
    # 判断域名是否可用    
    resp = is_domain_reachable(github_api_domain)
    if resp == False:         
        print("域名不可用 {}".format(github_api_domain),) 
        sys.exit()  
          
    # 验证token是否可用      
    resp,error = login()  
    if resp == False:                
        print(error) 
        sys.exit()   
     
    # 远端仓库不存在才会创建
    if isRepoExist() == False: 
        # 请求远程创建仓库   
        resp,error = createRepo()         
        if resp == False:           
            print(error)
            sys.exit()  
  
    # 判断一下本地仓库  
    if os.path.exists("./{}".format(repo_name)) == False: 
        #克隆仓库 
        success = cloneRepo() 
        if success == False:
            print("克隆仓库失败")  
            sys.exit()
            
    # 推送远端     
    err,resp = pushRepo()    
    if ("success" in err) == False:  
        print(err) 
        sys.exit() 
       
    # 清理仓库文件夹     
    err = deleteRepo() 
    if len(err) > 0:  
        print(err) 
        sys.exit() 
        
    print("success#https://github.com/{}/{}.git".format(github_user_name,repo_name)) 
